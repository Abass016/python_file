#write a fumction that add even number
# write a number that subtract a number from a number
# write a function that multiply two numbers
# write a function has the return statement

# make sure your function are in return statement

# print("You are asked to solve this question consecutively")

# def adds(first, second) :
#     return  first + second

# def subt(first, second):
#     return first - second

# def mult(first, second):
#     return first * second

# def ide(first, second):
#     return first / second





# print(adds(4, 6 ))

# print(subt(6, 4 ))

# print(mult(8, 6))

# print(ide(8, 2))

# number = 10

# def plusOne():
#     return number + 1

# def minusOne():
#     return number - 1

# def multiplyTwo():
#     global number
#     number = 15
#     return number * 2

# print(plusOne())
# print(minusOne())
# print(multiplyTwo())

Car = ["lexus es350", "benz c300","corolla 2007"]

print(Car[2])
Car.clear()
print(Car)

print(Car)
countries = {
    "france": "paris",
    "Japan": "tokyo",
    "canada": "ottawa",
    "mongolia":"ulanbaantaar"
}

capital_of_mongolia =  countries["mongolia"]

    

# paramters and variables ina function are set to exit in the functions local scope
# paramters and variables outside of all functions are set to exit in a global scope



# RULES OF SCOPE

# Codes in the global scope cannot use any local variable
# Code in a local scope can accept global variables
# Code in one function local scope cannot use variables in another functions local scope
# code in one function local scope cannot use variables in any other local scope