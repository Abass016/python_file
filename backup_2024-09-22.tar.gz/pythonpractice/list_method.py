list_of_colors = ["blue","red","white","purple","green","yellow","black","pink"]  

print(list_of_colors.index("black"))

print(list_of_colors.index("pink"))

list_of_colors.append("brown")

list_of_colors.insert(5, "indigo")

print(list_of_colors)

list_of_number = [10,1, 5,2,4,5,20,8,6,7,9,11,33,50,592,4,404,501,100]

list_of_number.sort()
list_of_number.sort(reverse=True)
print(list_of_number)

list_of_colors.sort()

print(list_of_colors)

alpha = ["a", "B", "Z", "z", "b","A"]

alpha.sort()

print(alpha)

list_of_colors.remove("black ")
print(list_of_colors)