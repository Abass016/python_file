for i in range(4):
    print(i)

for i in [0,1,2,3,4]:
    print(i)


list_of_colors = ["blue","red","white","purple","green","yellow","black","pink"]        

for colors in list_of_colors:
    print(colors)

for i in range(len(list_of_colors)):
    print("The value of index " + str(i) + " is " + list_of_colors[i])    

    