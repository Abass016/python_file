

#num = [1, 2, 3, 4, 5, 6, 7, 8, 9,10]

#for i in num:
  #  print(i * 2)





for i in range(4):
    print(i)

for i in [0,1,2,3,4]:
    print(i)


list_of_colors = ["blue","red","white","purple","green","yellow","black","pink"]        

for colors in list_of_colors:
    print(colors)



