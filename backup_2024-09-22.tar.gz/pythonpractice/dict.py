# A dictionary is a collection of many values 
# Dictionaries are a representation of key value pairs

# Dictionary are key value

animaks = ["lion", "cow"]

print(animaks[0])

my_car = {"Brand" : "lexus", "model" : "is250"}

print("I have a " + my_car["Brand"] + " of model " + my_car["model"])
Carr = ["lexus es350", "benz c300","corolla 2007"]

print(Car[2])
Car.clear()

countries = {
    "france": "paris",
    "Japan": "tokyo",
    "canada": "ottawa",
    "mongolia":"ulanbaantaar"
}

capital_of_mongolia =  countries["mongolia"]

countries["Nigeria"] = "Abuja"
countries["USA"] = "Washington DC"

print(list(countries.items()))

print(countries)

for key in (countries.keys()):
    print("this is country ", key)

for values in countries.values():
    print(values)

for state, capital in countries.items():
    print("the capital of " + state + " is " + capital)   

toyota = {
    "model" : "venza"
    "p"
}        



# in and not in
# PRODUCT DICTIONARY

# In that product
# it must be a dictionary = {product1:{}, product2:{}}
# {product}
